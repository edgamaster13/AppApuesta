/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.dao;

import MODELO.Apuesta;
import MODELO.Conexion3;
import MODELO.Respuesta;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;
import java.util.List;

/**
 *
 * @author Alejandro
 */
public class DAO_Respuesta extends Conexion3 implements DAO<Respuesta> {

    public DAO_Respuesta() throws ClassNotFoundException, SQLException {
        super("ResDbApuesta");
    }

    @Override
    public void create(Respuesta ob) throws SQLException {
        crear("INSERT INTO respuesta (respuesta) VALUES('"+ob.getRespuesta()+"')");
    }

    @Override
    public List<Respuesta> read() throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void update(Respuesta ob) throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void delete(String id) throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Respuesta> read(String txt) throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Respuesta findByID(String id) throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    public static LinkedList<Respuesta> getRespuesta() throws SQLException {
        LinkedList<Respuesta> lista = new LinkedList<Respuesta>();
        try{
        Class.forName("org.apache.derby.jdbc.ClientDriver");
         Connection conexion = DriverManager.getConnection(
            "jdbc:derby://localhost:1527/ResDbApuesta");
        Statement st = conexion.createStatement();
        ResultSet rs = st.executeQuery("SELECT * FROM respuesta where id = (SELECT max(id) FROM (respuesta))");
        
        Respuesta res;
        while(rs.next()){
            res = new Respuesta();
            
            res.setId(rs.getString(1));
            res.setRespuesta(rs.getString(2));
            
            lista.add(res);
        }
        rs.close();
        st.close();
        }catch(Exception e){
            e.printStackTrace();
        }
        return lista;
        
        
    }
    
}
