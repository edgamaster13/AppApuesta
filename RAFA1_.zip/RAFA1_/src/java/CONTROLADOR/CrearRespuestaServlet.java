/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CONTROLADOR;

import MODELO.Apuesta;
import MODELO.Respuesta;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.dao.DAO_Apuestas;
import model.dao.DAO_Respuesta;

/**
 *
 * @author Alejandro
 */
@WebServlet(name = "CrearRespuestaServlet", urlPatterns = {"/CrearRespuestaServlet"})
public class CrearRespuestaServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
            
        try {
            Respuesta res = new Respuesta();
            
            res.setRespuesta(request.getParameter("res"));
            
            
            DAO_Respuesta dr = new DAO_Respuesta();
            dr.create(res);
            
            request.getRequestDispatcher("NewApuesta.jsp").forward(request,response);
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(CrearUsuarioServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    }
